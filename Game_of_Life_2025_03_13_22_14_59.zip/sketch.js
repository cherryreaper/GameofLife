//variables
let length = 8;
let columns, rows, board, neighborsAlive;

function setup() {
  createCanvas(400, 400);

  //variables
  columns = width / length;
  rows = height / length;

  //make the board
  board = create2DArray(columns, rows);
  //fill the board with Cells of (1||0)
  for (let i = 1; i < columns - 1; i++) {
    for (let j = 1; j < rows - 1; j++) {
      board[i][j] = new Cell(floor(random(2)));
    }
  }
}

function draw() {
  background(220);
  for (let i = 1; i < columns - 1; i++) {
    for (let j = 1; j < rows - 1; j++) {
      //varaible set
      cell = board[i][j];
      neighborsAlive = 0;

      //change state
      //count neighors first, then change accordingly
      for (let k = -1; k <= 1; k++) {
        for (let l = -1; l <= 1; l++) {
          if (k != 0 || l != 0) {
            neighborsAlive += board[i + k][j + l].lastGen;
          }
        }
      }

      //change
      //starve
      if (cell.state === 1 && neighborsAlive >= 4) cell.state = 0;
      else if (cell.state === 1 && neighborsAlive <= 1) cell.state = 0;
      //birth
      else if (cell.state === 0 && neighborsAlive === 3) cell.state = 1;
    }
  }
  for (let i = 1; i < columns - 1; i++) {
    for (let j = 1; j < rows - 1; j++) {
      //draw
      fill(255 - 255 * cell.state);
      square(i * length, j * length, length);
      stroke(0);

      cell = board[i][j];
      cell.lastGen = cell.state;
    }
  }
}

function create2DArray(columns, rows) {
  let myArray = new Array(columns);
  for (let i = 0; i < columns; i++) {
    myArray[i] = new Array(rows);
    for (let j = 0; j < rows; j++) {
      myArray[i][j] = new Cell(0, i * length, j * length, length);
    }
  }
  return myArray;
}

class Cell {
  constructor(state, x, y) {
    this.state = state;
    this.lastGen = state;
  }
}
